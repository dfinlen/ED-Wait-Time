﻿/// <reference path="Microsoft.Maps.d.ts" />
/// <reference path="Microsoft.Maps.AdvancedShapes.d.ts" />
/// <reference path="Microsoft.Maps.Overlay.Style.d.ts" />
/// <reference path="Microsoft.Maps.Search.d.ts" />
/// <reference path="Microsoft.Maps.Themes.BingTheme.d.ts" />
/// <reference path="Microsoft.Maps.Traffic.d.ts" />
/// <reference path="Microsoft.Maps.VenueMaps.d.ts" />
/// <reference path="Microsoft.Maps.Directions.d.ts" />