﻿/*
    Before you can access Microsoft.Maps.Overlays.Style styles, you must first load this module using the loadModule method.
    To load the new Bing Maps navigation bar, load the Microsoft.Maps.Overlays.Style module, then set  customizeOverlaysmap in
    the map options to true.
*/
declare module Microsoft.Maps.Overlay.Style {
}